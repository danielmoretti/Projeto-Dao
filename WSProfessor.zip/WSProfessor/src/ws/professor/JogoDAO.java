/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.professor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author joaquim
 */
public class JogoDAO {
    private PreparedStatement stmC;
    private PreparedStatement stmR;
    private PreparedStatement stmU;
    private PreparedStatement stmD;
    
    private Connection conn;
   
    
    public JogoDAO() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:derby://localhost:1527/banco","root","toor");
            
            this.stmC = this.conn.prepareStatement("INSERT INTO jogos(timea, timeb, golsa, golsb) VALUES(?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            this.stmR = this.conn.prepareStatement("SELECT * FROM jogos");
            this.stmU = this.conn.prepareStatement("UPDATE jogos SET timea=?, timeb=?, golsa=?, golsb=? WHERE id=?");
            this.stmD = this.conn.prepareStatement("DELETE FROM jogos WHERE id=?");
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public void close(){
        try{
            this.conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Jogo> read() {
        try {
            ResultSet rs = this.stmR.executeQuery();
            
            List<Jogo> jogos = new ArrayList<>();
            
            while(rs.next()) {
                Jogo p = new Jogo();
                p.setId(rs.getLong("id"));
                p.setTimea(rs.getString("Timea"));
                p.setTimeb(rs.getString("Timeb"));
                p.setGolsa(rs.getInt("Golsa"));
                p.setGolsb(rs.getInt("Golsb"));
                
                jogos.add(p);
            }
            
            return jogos;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
 
    public Jogo create(Jogo novoJogo) {
        try {
            this.stmC.setString(1, novoJogo.getTimea());
            this.stmC.setString(2, novoJogo.getTimeb());
            this.stmC.setInt(3, novoJogo.getGolsa());
            this.stmC.setInt(4, novoJogo.getGolsb());
            this.stmC.executeUpdate();
            
            ResultSet rs = this.stmC.getGeneratedKeys();
            rs.next();
            long id = rs.getLong(1);
            novoJogo.setId(id);
            
            return novoJogo;
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
