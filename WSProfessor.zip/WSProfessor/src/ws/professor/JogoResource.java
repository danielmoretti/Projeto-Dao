/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.professor;

/**
 *
 * @author 41611322
 */
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import io.dropwizard.jersey.params.*;
import java.util.*;

@Path("/jogos")
@Produces(MediaType.APPLICATION_JSON)
public class JogoResource {    

    private JogoDAO dao;
    
    public JogoResource(JogoDAO dao) {
        this.dao = dao;
    }
    
    @GET
    public List<Jogo> read() {
        return dao.read();
    }
    
    @POST
    public Jogo create(Jogo p) {
        return this.dao.create(p);
    }
    
    @GET
    @Path("{id}")
    public Jogo readOne(@PathParam("id") LongParam id) {
        long idJogo = id.get();
        // Precisa implementar no DAO
        return null;
    }
    
//
//    @PUT
//    @Path("{id}")
//    public Professor update(@PathParam("id") LongParam id, Professor p) {
//        for (Professor professor: professores) {
//            if (professor.getId() == id.get()) {
//                professor.setNome(p.getNome());
//                professor.setMatricula(p.getMatricula());
//                return professor;
//            }
//        }
//        return null;
//    }
//    
//    @DELETE
//    @Path("{id}")
//    public Response delete(@PathParam("id") LongParam id) {
//        Professor p = null;
//        for (Professor professor: professores) {
//            if (professor.getId() == id.get()) {
//                p = professor;
//                break;
//            }
//        }
//        if (p != null) { 
//            professores.remove(p); 
//        }
//        else {
//            throw new WebApplicationException("Professor com id=" + id.get() 
//                                              + " não encontrado!", 404);
//        }
//        return Response.ok().build();
//    }
}

