/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.professor;

/**
 *
 * @author 41611322
 */
public class Jogo {
    private long id;
    private String timea;
    private String timeb;
    private int golsa;
    private int golsb;
    
    
    public Jogo() {}
    
    public Jogo(long id, String timea, String timeb, int golsa, int golsb) {
        this.id = id;
        this.timea = timea;
        this.timeb = timeb;        
        this.golsa = golsa;
        this.golsb = golsb;
    }
    
    public long getId() { return id; }
    public String getTimea() { return timea; }
    public String getTimeb() { return timeb; }
    public int getGolsa() { return golsa; }
    public int getGolsb() { return golsb; }
    
    public void setId(long id) { this.id = id; }
    public void setTimea(String timea) { this.timea = timea; }
    public void setTimeb(String timeb) { this.timeb = timeb; }
    public void setGolsa(int golsa) { this.golsa = golsa; }
    public void setGolsb(int golsb) { this.golsb = golsb; }
    
    @Override
    public String toString() {
        return "Jogo: " 
                + this.timea + " X " 
                + this.timeb + " - "
                + this.golsa + " - "
                + this.golsb + " (" 
                + this.id + ")";
    }
}

